import cv2
import os
import time
import numpy as np
from pathlib import Path

def add_watermark(image, watermark_text="PDC_LAB"):
    """
    Add a watermark to the image
    """
    watermarked = image.copy()
    
    height, width = watermarked.shape[:2]
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    color = (255, 255, 255)  
    thickness = 2
    
    (text_width, text_height), baseline = cv2.getTextSize(watermark_text, font, font_scale, thickness)
    
    x = width - text_width - 10
    y = height - 10
    
    overlay = watermarked.copy()
    cv2.rectangle(overlay, (x-5, y-text_height-5), (x+text_width+5, y+5), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, watermarked, 0.4, 0, watermarked)
    
    cv2.putText(watermarked, watermark_text, (x, y), font, font_scale, color, thickness)
    
    return watermarked

def process_image(input_path, output_path):
    """
    Process a single image: resize to 128x128 and add watermark
    """
    try:
        image = cv2.imread(input_path)
        if image is None:
            print(f"Warning: Could not read image {input_path}")
            return False
        
        resized_image = cv2.resize(image, (128, 128))
        
        watermarked_image = add_watermark(resized_image)
        
        cv2.imwrite(output_path, watermarked_image)
        return True
        
    except Exception as e:
        print(f"Error processing {input_path}: {str(e)}")
        return False

def sequential_process():
    """
    Main function to process all images sequentially
    """
    start_time = time.time()
    
    input_dir = "images_dataset"
    output_dir = "output_seq"
    
    os.makedirs(output_dir, exist_ok=True)
    
    class_folders = [f for f in os.listdir(input_dir) if os.path.isdir(os.path.join(input_dir, f))]
    
    total_images = 0
    processed_images = 0
    
    print("Starting sequential image processing...")
    print(f"Found {len(class_folders)} class folders: {class_folders}")
    
    for class_folder in class_folders:
        print(f"\nProcessing class: {class_folder}")
        
        output_class_dir = os.path.join(output_dir, class_folder)
        os.makedirs(output_class_dir, exist_ok=True)
        
        class_path = os.path.join(input_dir, class_folder)
        image_files = [f for f in os.listdir(class_path) 
                      if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff'))]
        
        print(f"Found {len(image_files)} images in {class_folder}")
        
        for image_file in image_files:
            input_path = os.path.join(class_path, image_file)
            output_path = os.path.join(output_class_dir, image_file)
            
            total_images += 1
            
            if process_image(input_path, output_path):
                processed_images += 1
                print(f" Processed: {image_file}")
            else:
                print(f" Failed: {image_file}")
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    print(f"\n{'='*50}")
    print(f"Sequential Processing Complete!")
    print(f"Total images found: {total_images}")
    print(f"Successfully processed: {processed_images}")
    print(f"Failed: {total_images - processed_images}")
    print(f"Sequential Processing Time: {execution_time:.2f} seconds")
    print(f"{'='*50}")

if __name__ == "__main__":
    sequential_process()