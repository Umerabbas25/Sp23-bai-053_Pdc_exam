import cv2
import os
import time
import multiprocessing as mp

INPUT_DIR = "images_dataset"
OUTPUT_DIR = "output_distributed"
SEQUENTIAL_TIME = 5.8  

def get_all_images(root_dir):
    image_paths = []
    for folder, _, files in os.walk(root_dir):
        for file in files:
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                image_paths.append(os.path.join(folder, file))
    return image_paths


def process_images(node_name, image_list, return_dict):
    start = time.time()
    count = 0

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for img_path in image_list:
        try:
            img = cv2.imread(img_path)
            if img is None:
                print(f"{node_name} skipped (cannot read): {img_path}")
                continue

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            file_name = os.path.basename(img_path)
            save_path = os.path.join(OUTPUT_DIR, f"{node_name}_{file_name}")
            cv2.imwrite(save_path, gray)
            count += 1

        except Exception as e:
            print(f"Error in {node_name} for {img_path}: {e}")

    end = time.time()
    node_time = end - start
    return_dict[node_name] = (count, node_time)


def main():
    print("Starting Distributed Image Processing Simulation...")
    print("=" * 60)

    all_images = get_all_images(INPUT_DIR)
    total_images = len(all_images)
    if total_images == 0:
        print("No images found in images_dataset folder.")
        return

    print(f"Total images to process: {total_images}")
    print("Distributing among 2 nodes...")

    half = total_images // 2
    node1_images = all_images[:half]
    node2_images = all_images[half:]

    manager = mp.Manager()
    return_dict = manager.dict()

    start_time = time.time()

    p1 = mp.Process(target=process_images, args=("Node1", node1_images, return_dict))
    p2 = mp.Process(target=process_images, args=("Node2", node2_images, return_dict))
    p1.start()
    p2.start()
    p1.join()
    p2.join()

    total_time = time.time() - start_time

    print("\n" + "=" * 60)
    print("DISTRIBUTED PROCESSING RESULTS")
    print("=" * 60)

    total_processed = 0
    for node, (count, node_time) in return_dict.items():
        print(f"{node} processed {count} images in {node_time:.2f}s")
        total_processed += count

    efficiency = SEQUENTIAL_TIME / total_time if total_time > 0 else 0
    print(f"Total distributed time: {total_time:.2f}s")
    print(f"Efficiency: {efficiency:.2f}x over sequential")
    print("=" * 60)


if __name__ == "__main__":
    main()
