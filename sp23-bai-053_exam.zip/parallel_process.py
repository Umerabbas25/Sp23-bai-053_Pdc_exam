import cv2
import os
import time
import numpy as np
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from multiprocessing import cpu_count
import multiprocessing

def add_watermark(image, watermark_text="PDC_LAB"):
    """
    Add a watermark to the image
    """
    watermarked = image.copy()
    
    height, width = watermarked.shape[:2]
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    color = (255, 255, 255)
    thickness = 2
    
    (text_width, text_height), baseline = cv2.getTextSize(watermark_text, font, font_scale, thickness)
    
    x = width - text_width - 10
    y = height - 10
    
    overlay = watermarked.copy()
    cv2.rectangle(overlay, (x-5, y-text_height-5), (x+text_width+5, y+5), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, watermarked, 0.4, 0, watermarked)
    
    cv2.putText(watermarked, watermark_text, (x, y), font, font_scale, color, thickness)
    
    return watermarked

def process_image(input_path, output_path):
    """
    Process a single image: resize to 128x128 and add watermark
    """
    try:
        image = cv2.imread(input_path)
        if image is None:
            print(f"Warning: Could not read image {input_path}")
            return False
        
        resized_image = cv2.resize(image, (128, 128))
        
        watermarked_image = add_watermark(resized_image)
        
        cv2.imwrite(output_path, watermarked_image)
        return True
        
    except Exception as e:
        print(f"Error processing {input_path}: {str(e)}")
        return False

def get_all_image_tasks(input_dir, output_dir):
    """
    Get all image processing tasks
    """
    tasks = []
    
    class_folders = [f for f in os.listdir(input_dir) if os.path.isdir(os.path.join(input_dir, f))]
    
    for class_folder in class_folders:
        output_class_dir = os.path.join(output_dir, class_folder)
        os.makedirs(output_class_dir, exist_ok=True)
        
        class_path = os.path.join(input_dir, class_folder)
        image_files = [f for f in os.listdir(class_path) 
                      if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff'))]
        
        for image_file in image_files:
            input_path = os.path.join(class_path, image_file)
            output_path = os.path.join(output_class_dir, image_file)
            tasks.append((input_path, output_path))
    
    return tasks

def parallel_process_with_workers(num_workers, use_threads=True):
    """
    Process images in parallel with specified number of workers
    """
    start_time = time.time()
    
    input_dir = "images_dataset"
    output_dir = f"output_parallel_{num_workers}workers"
    
    os.makedirs(output_dir, exist_ok=True)
    
    tasks = get_all_image_tasks(input_dir, output_dir)
    
    print(f"Processing {len(tasks)} images with {num_workers} {'threads' if use_threads else 'processes'}")
    
    processed_count = 0
    
    if use_threads:
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = [executor.submit(process_image, input_path, output_path) 
                      for input_path, output_path in tasks]
            
            for future in futures:
                if future.result():
                    processed_count += 1
    else:
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            futures = [executor.submit(process_image, input_path, output_path) 
                      for input_path, output_path in tasks]
            
            for future in futures:
                if future.result():
                    processed_count += 1
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    print(f"Completed: {processed_count}/{len(tasks)} images processed")
    return execution_time

def parallel_process():
    """
    Main function to test parallel processing with different worker counts
    """
    print("Starting Parallel Image Processing Tests...")
    print("=" * 60)
    
    worker_configs = [1, 2, 4, 8]
    results = []
    
    for num_workers in worker_configs:
        print(f"\nTesting with {num_workers} worker(s)...")
        
        execution_time = parallel_process_with_workers(num_workers, use_threads=True)
        results.append((num_workers, execution_time))
        
        print(f"Time with {num_workers} worker(s): {execution_time:.2f} seconds")
    
    baseline_time = results[0][1] 
    speedup_results = []
    
    for workers, time_taken in results:
        speedup = baseline_time / time_taken
        speedup_results.append((workers, time_taken, speedup))
    
    print("\n" + "=" * 60)
    print("PARALLEL PROCESSING RESULTS")
    print("=" * 60)
    print(f"{'Workers':<8} | {'Time (s)':<10} | {'Speedup':<10}")
    print("-" * 60)
    
    for workers, time_taken, speedup in speedup_results:
        print(f"{workers:<8} | {time_taken:<10.2f} | {speedup:<10.2f}x")
    
    print("=" * 60)
    
    best_config = max(speedup_results, key=lambda x: x[2])
    print(f"Best configuration: {best_config[0]} workers with {best_config[2]:.2f}x speedup")
    
    best_workers = best_config[0]
    for workers, _, _ in speedup_results:
        if workers != best_workers:
            import shutil
            folder_to_remove = f"output_parallel_{workers}workers"
            if os.path.exists(folder_to_remove):
                shutil.rmtree(folder_to_remove)
                print(f"Removed temporary folder: {folder_to_remove}")
    
    best_folder = f"output_parallel_{best_workers}workers"
    if os.path.exists(best_folder):
        if os.path.exists("output_parallel"):
            shutil.rmtree("output_parallel")
        os.rename(best_folder, "output_parallel")
        print(f"Renamed {best_folder} to output_parallel")

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    parallel_process()
